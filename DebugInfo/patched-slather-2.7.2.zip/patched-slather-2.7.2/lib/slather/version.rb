module Slather
  VERSION = '2.7.2' unless defined?(Slather::VERSION)
end
