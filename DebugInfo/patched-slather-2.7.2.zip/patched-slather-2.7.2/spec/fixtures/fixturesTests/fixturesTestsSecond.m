//
//  fixturesTestsSecond.m
//  fixturesTests
//
//  Created by Mark Larsen on 6/24/14.
//  Copyright (c) 2014 marklarr. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface fixturesTestsSecond : XCTestCase

@end

@implementation fixturesTestsSecond

- (void)testExample
{
}

@end
