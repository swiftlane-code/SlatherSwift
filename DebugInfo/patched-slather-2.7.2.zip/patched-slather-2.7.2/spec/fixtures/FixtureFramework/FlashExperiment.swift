import Foundation

public struct FlashExperiment {
    public let isAwesome = true
    
    public init() {}
}
