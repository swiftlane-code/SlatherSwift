//
//  FixtureFramework.h
//  FixtureFramework
//
//  Created by Stephen Williams on 11/03/21.
//  Copyright © 2021 marklarr. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for FixtureFramework.
FOUNDATION_EXPORT double FixtureFrameworkVersionNumber;

//! Project version string for FixtureFramework.
FOUNDATION_EXPORT const unsigned char FixtureFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FixtureFramework/PublicHeader.h>


