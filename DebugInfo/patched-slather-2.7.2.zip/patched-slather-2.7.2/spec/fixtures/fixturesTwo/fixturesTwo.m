//
//  fixturesTwo.m
//  fixturesTwo
//
//  Created by Kent Sutherland on 4/17/16.
//  Copyright © 2016 marklarr. All rights reserved.
//

#import "fixturesTwo.h"

@implementation fixturesTwo

- (NSInteger)doSomething
{
    NSInteger a = 5;
    NSInteger b = 6;

    return a + b;
}

@end
