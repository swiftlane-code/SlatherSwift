//
//  peekaview.h
//  fixtures
//
//  Created by Mark Larsen on 6/25/14.
//  Copyright (c) 2014 marklarr. All rights reserved.
//

#import <AppKit/AppKit.h>

@interface peekaview : NSView

@end
