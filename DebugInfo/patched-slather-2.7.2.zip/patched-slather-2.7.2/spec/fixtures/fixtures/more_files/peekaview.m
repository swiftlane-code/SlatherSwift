//
//  peekaview.m
//  fixtures
//
//  Created by Mark Larsen on 6/25/14.
//  Copyright (c) 2014 marklarr. All rights reserved.
//

#import "peekaview.h"

@implementation peekaview

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
