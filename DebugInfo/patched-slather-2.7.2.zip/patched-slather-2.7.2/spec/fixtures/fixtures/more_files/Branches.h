//
//  Branches.h
//  fixtures
//
//  Created by Julian Krumow on 11.10.14.
//  Copyright (c) 2014 marklarr. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Branches : NSObject

- (void)branches:(BOOL)goIf skipBranches:(BOOL)skipBranches;

@end
