//
//  Empty.m
//  fixtures
//
//  Created by Julian Krumow on 27.10.14.
//  Copyright (c) 2014 marklarr. All rights reserved.
//

#import "Empty.h"

@implementation Empty

@end
