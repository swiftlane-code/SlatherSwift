#import <Foundation/Foundation.h>

@interface fixtures_m : NSObject

@end
