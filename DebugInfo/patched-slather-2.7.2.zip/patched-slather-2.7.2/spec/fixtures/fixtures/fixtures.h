//
//  fixtures.h
//  fixtures
//
//  Created by Mark Larsen on 6/24/14.
//  Copyright (c) 2014 marklarr. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface fixtures : NSObject

- (void)testedMethod;
- (void)untestedMethod;

@end
