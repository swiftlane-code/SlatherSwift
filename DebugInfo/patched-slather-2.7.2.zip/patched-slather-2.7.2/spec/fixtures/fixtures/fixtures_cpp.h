#ifndef __fixtures__fixtures_cpp__
#define __fixtures__fixtures_cpp__

#include <stdio.h>

#endif /* defined(__fixtures__fixtures_cpp__) */
