#import <Foundation/Foundation.h>

@interface fixtures_mm : NSObject

@end
